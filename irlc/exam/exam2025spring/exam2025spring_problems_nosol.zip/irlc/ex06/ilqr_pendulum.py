# This file may not be shared/redistributed without permission. Please read copyright notice in the git repo. If this file contains other copyright notices disregard this text.
import numpy as np
from irlc.ex04.model_pendulum import DiscreteSinCosPendulumModel
import matplotlib.pyplot as plt
import time
from irlc.ex06.ilqr_rendovouz_basic import ilqr
from irlc import savepdf

def pendulum(use_linesearch):
    print("> Using iLQR to solve Pendulum swingup task. Using linesearch?", use_linesearch)
    dt = 0.02
    model = DiscreteSinCosPendulumModel(dt, cost=None)
    N = 250
    # This rather clunky line gets us the initial state; we transform the bound by the variable transformation.
    x0 = np.asarray(model.phi_x(model.continuous_model.x0_bound().low))

    n_iter = 200 # Use 200 iLQR iterations.
    # xs, us, J_hist, L, l = ilqr(model, ...) Write a function call like this, but with the correct parametesr
    xs, us, J_hist, L, l = ilqr(model, N, x0, n_iter=n_iter, use_linesearch=use_linesearch)  #!b #!b Call iLQR here (see hint above).

    render = True
    if render:
        for i in range(2):
            render_(xs, model)
            time.sleep(2) # Sleep for two seconds between simulations.
    model.close()
    xs = np.asarray([model.phi_x_inv(x) for x, u in zip(xs, us)]) # Convert to Radians. We use the build-in functions to change coordinates.
    xs, us = np.asarray(xs), np.asarray(us)

    t = np.arange(N) * dt
    theta = np.unwrap(xs[:, 0])  # Makes for smoother plots.
    theta_dot = xs[:, 1]

    pdf_ex = '_linesearch' if use_linesearch else ''
    stitle = "(using linesearch)" if use_linesearch else "(not using linesearch) "
    ev = 'pendulum_'
    _ = plt.plot(theta, theta_dot)
    _ = plt.xlabel("$\\theta$ (rad)")
    _ = plt.ylabel("$d\\theta/dt$ (rad/s)")
    _ = plt.title(f"Phase Plot {stitle}")
    plt.grid()
    savepdf(f"{ev}theta{pdf_ex}")
    plt.show()

    _ = plt.plot(t, us)
    _ = plt.xlabel("time (s)")
    _ = plt.ylabel("Force (N)")
    _ = plt.title(f"Action path {stitle}")
    plt.grid()
    savepdf(f"{ev}action{pdf_ex}")
    plt.show()

    _ = plt.plot(J_hist)
    _ = plt.xlabel("Iteration")
    _ = plt.ylabel("Total cost")
    _ = plt.title(f"Total cost-to-go {stitle}")
    plt.grid()
    savepdf(f"{ev}J{pdf_ex}")
    plt.show()

def render_(xs, env):
    for i in range(xs.shape[0]):
        env.render(xs[i])

if __name__ == "__main__":
    pendulum(use_linesearch=False)
    pendulum(use_linesearch=True)
