# This file may not be shared/redistributed without permission. Please read copyright notice in the git repo. If this file contains other copyright notices disregard this text.
"""

References:
  [SB18] Richard S. Sutton and Andrew G. Barto. Reinforcement Learning: An Introduction. The MIT Press, second edition, 2018. (Freely available online).
"""
import numpy as np
import matplotlib.pyplot as plt
from irlc.ex07.simple_agents import BasicAgent
from irlc.ex07.bandits import StationaryBandit, eval_and_plot
from irlc import savepdf

class NonstationaryBandit(StationaryBandit):
    def __init__(self, k, q_star_mean=0, reward_change_std=0.01):
        self.reward_change_std = reward_change_std
        super().__init__(k, q_star_mean)

    def bandit_step(self, a): #!f
        r""" Implement the non-stationary bandit environment (as described in (SB18)).
        Hint: use reward_change_std * np.random.randn() to generate a single random number with the given std.
         then add one to each coordinate. Remember you have to compute the regret as well, see StationaryBandit for ideas.
         (remember the optimal arm will change when you add noise to q_star) """
        self.q_star += self.reward_change_std * np.random.randn(self.k)
        self.optimal_action = np.argmax(self.q_star)
        return super().bandit_step(a)

    def __str__(self):
        return f"{type(self).__name__}_{self.q_star_mean}_{self.reward_change_std}"


class MovingAverageAgent(BasicAgent):
    r"""
    The simple bandit from (SB18, Section 2.4), but with moving average alpha
    as described in (SB18, Eqn. (2.3))
    """
    def __init__(self, env, epsilon, alpha): #!f
        self.alpha=alpha
        super().__init__(env, epsilon=epsilon)

    def train(self, s, a, r, sp, done=False, info_s=None, info_sp=None): #!f
        self.Q[a] = self.Q[a] + self.alpha * (r-self.Q[a])

    def __str__(self):
        return f"{type(self).__name__}_{self.epsilon}_{self.alpha}"


if __name__ == "__main__":
    plt.figure(figsize=(10, 10))
    epsilon = 0.1
    alphas = [0.15, 0.1, 0.05]

    bandit = NonstationaryBandit(k=10) #!b

    agents = [BasicAgent(bandit, epsilon=epsilon)]
    agents += [MovingAverageAgent(bandit, epsilon=epsilon, alpha=alpha) for alpha in alphas] #!b

    labels = [f"Basic agent, epsilon={epsilon}"]
    labels += [f"Mov.avg. agent, epsilon={epsilon}, alpha={alpha}" for alpha in alphas] #!b #!b
    use_cache = False # Set this to True to use cache (after code works!)
    eval_and_plot(bandit, agents, steps=10000, num_episodes=200, labels=labels, use_cache=use_cache)
    savepdf("nonstationary_bandits")
    plt.show()
