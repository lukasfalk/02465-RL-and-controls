# This file may not be shared/redistributed without permission. Please read copyright notice in the git repo. If this file contains other copyright notices disregard this text.
import numpy as np
from gymnasium.spaces.discrete import Discrete
from gymnasium import Env
from irlc.ex01.agent import Agent, train

class InventoryEnvironment(Env): 
    def __init__(self, N=2):
        self.N = N                               # planning horizon
        self.action_space      = Discrete(3)     # Possible actions {0, 1, 2}
        self.observation_space = Discrete(3)     # Possible observations {0, 1, 2}

    def reset(self):
        self.s = 0                               # reset initial state x0=0
        self.k = 0                               # reset time step k=0
        return self.s, {}                        # Return the state we reset to (and an empty dict)

    def step(self, a):
        w = np.random.choice(3, p=(.1, .7, .2))    # Generate random disturbance
        s_next = max(0, min(2, self.s-w+a))           # next state; x_{k+1} =  f_k(x_k, u_k, w_k) #!b
        reward = -(a + (self.s + a - w)**2)           # reward = -cost      = -g_k(x_k, u_k, w_k)
        terminated = self.k == self.N-1               # Have we terminated? (i.e. is k==N-1)
        self.s = s_next                               # update environment state
        self.k += 1                                   # update current time step #!b
        return s_next, reward, terminated, False, {}  # return transition information  

class RandomAgent(Agent): 
    def pi(self, s, k, info=None): #!f
        """ Return action to take in state s at time step k """
        return np.random.choice(3) # Return a random action 


def simplified_train(env: Env, agent: Agent) -> float: 
    s, _ = env.reset()
    J = 0  # Accumulated reward for this rollout
    for k in range(1000):
        a = agent.pi(s, k) #!b;permute
        sp, r, terminated, truncated, metadata = env.step(a)
        agent.train(s, a, sp, r, terminated)
        s = sp
        J += r
        if terminated or truncated:
            break #!b
    return J 

def run_inventory():
    env = InventoryEnvironment() 
    agent = RandomAgent(env)
    stats, _ = train(env,agent,num_episodes=1,verbose=False)  # Perform one rollout.
    print("Accumulated reward of first episode", stats[0]['Accumulated Reward']) 
    # I recommend inspecting 'stats' in a debugger; why do you think it is a list of length 1?

    stats, _ = train(env, agent, num_episodes=1000,verbose=False)  # do 1000 rollouts 
    avg_reward = np.mean([stat['Accumulated Reward'] for stat in stats])
    print("[RandomAgent class] Average cost of random policy J_pi_random(0)=", -avg_reward) 
    # Try to inspect stats again in a debugger here. How long is the list now?

    stats, _ = train(env, Agent(env), num_episodes=1000,verbose=False)  # Perform 1000 rollouts using Agent class 
    avg_reward = np.mean([stat['Accumulated Reward'] for stat in stats])
    print("[Agent class] Average cost of random policy J_pi_random(0)=", -avg_reward)  

    """ Second part: Using the simplified training method. I.e. do not use train() below.
     You can find some pretty strong hints about what goes on in simplified_train in the lecture slides for today. """
    avg_reward_simplified_train = np.mean( [simplified_train(env, agent) for i in range(1000)]) 
    print("[simplified train] Average cost of random policy J_pi_random(0) =", -avg_reward_simplified_train)  



if __name__ == "__main__":
    run_inventory()
